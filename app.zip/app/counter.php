<?php
class counter {
    public $link='';

    function __construct() {
        $this->connect();
    }

    function connect() {
        $this->link = mysqli_connect('localhost', 'root', '', 'group_project') or die('Cannot connect to the DB');
    }

    function getAllData() {
        $query = "SELECT  * FROM counter"; //  select  *
        $result = mysqli_query($this->link, $query) or die('Error fetching data from database: '.$query);
        $data = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        return $data;
    }
}

$counter = new counter();
$data = $counter->getAllData();
?>
