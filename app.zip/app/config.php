<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "group_project";

$conn = new mysqli($servername, $username, $password, $database);

// Check 
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//  username and password 
$username = $_POST['username'];
$password = $_POST['password'];


$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result = $conn->query($sql);


if ($result->num_rows > 0) {

    $_SESSION['username'] = $username;

    //  home.php
    header("Location: home.php");
    exit();
} else {
    //  login page 
    header("Location: login.php?error=1");
    exit();
}

$conn->close();
?>
