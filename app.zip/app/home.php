<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="styles.css">   
</head>
<body>
<center>
    <h2>Welcome to  Admin Page</h2>

    <?php
    // Include the PHP script that retrieves data from the database
    require_once 'counter.php';
    ?>
    <?php if (isset($data) && !empty($data)): ?>
        <br><br>
    <div>
    
        <h3>Counter Data</h3>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Red</th>
                <th>Blue</th>
                <th>Green</th>
                <th>Total</th>
                <th>Time</th>
            </tr>
            <?php foreach($data as $row): ?>
            <tr>
                <td><?php echo $row['ID']; ?></td>
                <td><?php echo $row['Red']; ?></td>
                <td><?php echo $row['Blue']; ?></td>
                <td><?php echo $row['Green']; ?></td>
                <td><?php echo $row['Total']; ?></td>
                <td><?php echo $row['Time']; ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <br><br>
    <?php else: ?>
    <p>No data available.</p>
    <?php endif; ?>
    <form action="logout.php" method="POST">
        <button type="submit" class="button1">Logout</button>
    </form>
    </center>
</body>
</html>
