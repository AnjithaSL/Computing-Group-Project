<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="styles.css">
    <?php
    if (isset($_GET['error']) && $_GET['error'] == 1) {
        echo "<p class='error-message' >Incorrect username or password. Please try again.</p>";
    }
    ?>
</head>
<body>
    <div class="container">
        <form action="config.php" method="POST" class="login-form" >
            <h2>Login Page</h2>
            <div class="group">
                <input type="text" id="username" name="username" required placeholder="Username">
            </div>
            <div class="group">
                <input type="password" id="password" name="password" required placeholder="Password">
            </div>
            <button type="submit" class="button">Login</button>

        </form>
    </div>
</body>
</html>
